from django.shortcuts import render

# Create your views here.

# 게시글 목록
# 게시글 작성
# 게시글 조회
# 게시글 수정
# 게시글 삭제
