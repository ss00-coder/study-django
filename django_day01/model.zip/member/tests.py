import os
import django
from django.test import TestCase

# Create your tests here.

os.environ['DJANGO_SETTINGS_MODULE'] = 'app.settings'
os.environ['DJANGO_ALLOW_ASYNC_UNSAFE'] = 'true'
django.setup()


class MemberTest(TestCase):

    def test_save(self):
        pass